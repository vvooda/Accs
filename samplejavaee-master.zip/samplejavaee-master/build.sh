#!/bin/sh
mvn clean assembly:assembly
